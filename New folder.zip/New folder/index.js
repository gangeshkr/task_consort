const express = require('express');
const bodyParser = require('body-parser');

const app = express();

//server port 
const port = process.env.PORT || 5000;

//parse req data
app.use(bodyParser.urlencoded({extended: false}));

//parse req data content type
app.use(bodyParser.json());

// def root route
app.get('/', (req, res)=>{
    res.send('Hello World');
});

//importing emp routes
const employeeRoutes = require('./src/routes/employee.route');

//create emp routes
app.use('/api/v1/employee', employeeRoutes);



// listen to the port
app.listen(port, ()=>{
    console.log('Server is running at port $(port)');
});