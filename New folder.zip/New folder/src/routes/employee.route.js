const express = require('express');
const { route } = require('express/lib/application');
const router = express.Router();

const EmployeeController = require('../controllers/employee.controller');

// get all employees
router.get('/', employeeController.getEmployeeList);

//get by id
router.get('/:id', employeeController.getEmployeeByID);

//create new emp
router.post('/', employeeController.createNewEmployee);

//update
router.put('/:id', employeeController.updateEmployee);

//deletero
router.delete('/:id', employeeController.deleteEmployee);

module.exports = router;