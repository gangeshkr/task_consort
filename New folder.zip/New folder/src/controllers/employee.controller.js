const Employee = require('../modles/employee.model');


//get employees
exports.getEmployeeList = (req, res)=> {
    //console.log('here all employee list');
    EmployeeModel.getAllEmployees((err, employees)=>{
        console.log('present here');
        if(err)
        res.send(err);
        console.log('Employees', employee);
        res.send(employees)
    })
}

//get emoployee by ID
exports.getEmployeeByID = (req, res)=>{
    //console.log('get emp by id');
    EmployeeModel.getAllEmployeesByID(req.params.id, (err, employee)=>{
        if(err)
        res.send(err);
        console.log('single employee data', employee);
        res.send(employee);
    })

}

//create new employee
exports.createNewEmployee = (req, res) =>{
    console.log('req data', employeeReqData);
    const employeeReqData = new EmployeeModel(req.body);
    //check null
    if(req.body.constructor === Object && Object.keys(req.body).length === 0){
        res.send(400).send({success: false, message: 'please fill all field'});
    }else{
        EmployeeModel.createEmployee(employeeReqData, (err, employee)=>{
            if(err)
                res.send(err);
                res.jason({status: true, message: 'created successfuly', data: employee});
        })
    }
}

//update employee
exports.updateEmployee = (req, res) =>{
    console.log('req data update', employeeReqData);
    const employeeReqData = new Employee(req.body);
    //check null
    if(req.body.constructor === Object && Object.keys(req.body).length === 0){
        res.send(400).send({success: false, message: 'please fill all field'});
    }else{
        EmployeeModel.updateEmployee(req.params.id, employeeReqData, (err, employee)=>{
            if(err)
                res.send(err);
                res.jason({status: true, message: 'updated successfuly', data: employee.insertedId});
        })
    }
}


//delete
exports.deleteEmployee = (req, res)=>{
    EmployeeModel.deleteEmployee(req.params.id, (err, employee)=>{
        if(err)
        res.send(err);
        res.jason({success: true, message: 'employee deleted'})
    })
}
