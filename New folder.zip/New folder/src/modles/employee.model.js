const { DATE } = require('mysql/lib/protocol/constants/types');
var dbConn = require('../../config/db.config');

var Employee = function(employee){
    this.id = employee.id;
    this.employee_name = employee.employee_name;
    this.employee_salary = employee.employee_salary;
    this.employee_age = employee.employee_age;
    this.profile_image = employee.profile_image;
    this.status = employee.status ? employee.status : 1;
    this.created_at = new Date();
    this.updated_at = new Date();
}

// get all employess
Employee.getAllEmployees = (result) =>{
    dbConn.query('SELECT * FROM employees', (err, res)=>{
        if(err){
            console.log('Error while fecthing employees', err);
            result(null, err);
        }else{
            console.log('fetched Successfully');
            result(null, res);
        }
    });

}

//get employee by id from Db
Employee.getEmployeeByID = (id, result)=>{
    dbConn.query('SELECT * FROM employees WHERE id = ?', id, (err, res)=>{
        if(err){
            console.log('error while fetching', err);
            result(null, err);
        }else{
            result(null, res);
        }
    });

}

//create new emp
Employee.createEmployee = (employeeReqData, result) =>{
    dbConn.query('INSERT INTO employees SET?', employeeReqData, (err, res)=>{
        if(err){
            console.log('error inserting data');
            result(null, err);
        }else{
            console.log('Employee created successfully');
            result(null, res);

        }
    });
}

//update employee
Employee.updateEmployee = (id, employeeReqData, result)=>{
    dbConn.query('UPDATE employees SET employee_name=?,employee_salary=?,employee_age=?,employee_image=? WHERE id=?', [employeeReqData.employee_name,employeeReqData.employee_salary,employeeReqData.employee_age, id], (err, res)=>{
        if(err){
            console.log('error while updating');
            result(null, err);
        }else{
            console.log('updated');
            result(null, res);
        }
    });
}

//delete
Employee.deleteEmployee = (id, result)=>{
    // dbConn.query('DELETE FROM employees WHERE id=?', [id], (err, res)=>{
    //     if(err){
    //         console.log('error while deleting');
    //         result(null, err);
    //     }else{
    //         result(null, res);
    //     }
    // })
    dbConn.query('UPDATE employees SET is_deleted=? WHERE id=?', [1, id], (err, res)=>{
        if(err){
            console.log('error while deleting');
            result(null, err);
        }else{
            console.log('deleted');
            result(null, res);
        }
    });

}
module.exports = Employee;